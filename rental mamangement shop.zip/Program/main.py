# Importing necessary modules
import os
import Rent
import Return
import Display

# Creating the main function for user interaction
def main():
    print("\n                           @@@@@@@@@|_______________________|@@@@@@@@@")
    print("\n                           @@@@@@@@@|  Welcome to Happy shop|@@@@@@@@@")
    print("\n                           @@@@@@@@@|=======================|@@@@@@@@@")

    while True:
        # Displaying the shop menu
        print("\n   #########@@@@@@@@@@@@@@@@@@@@@#######")
        print("     !*******|     Happy Shop     |******!")
        print("     !*******|____________________|******!")
        print("     !*******|1: Display Equipment|******!")
        print("     !*******|2: Rent  Equipment  |******!")
        print("     !*******|3: Return Equipment |******!")
        print("     !*******|4: Exit             |******!")
        print("     @@@@@@@@@#####################@@@@@@@")
        
        try:
            # Taking user input for action selection
            uInput = int(input(" Enter an option to proceed: >> "))
            
            # Option 1: Display available equipment
            if uInput == 1:
                Display.displayequipment()
                
            # Option 2: Rent equipment
            elif uInput == 2:
                isMade = Rent.userName()
                Rent.rentequipment(isMade)
                Rent.AllTotal()
                print("""-------------------------""")
                print("""|  PLEASE, VISIT AGAIN  |""")
                print("""-------------------------""")
                os.startfile(f"{Rent.userName}_Rent_Receipt.txt")
            
            # Option 3: Return equipment
            elif uInput == 3:
                isInit = Return.forreturning()
                Return.returnDetails(isInit)
                os.startfile(f"{Return.RName}_Return_Receipt.txt")
            
            # Option 4: Exit the program
            elif uInput == 4:
                print("\n**********!!!!!! |        Exiting Shopppp      | !!!!!!*********\n")
                print("\n**********!!!!!! |  Thank you for choosing us  | !!!!!!*********\n")
                break
            
            # Handling invalid input options
            else:
                print("\n!!------- Please, Choose a Given Option from 1 to 4 --------!!")
        
        # Handling input errors (non-integer input)
        except:
            print("\n!!-------- Please, Input Valid Option (Integer) -------!!")

# Checking if the script is being run as the main program
if __name__ == "__main__":
    main()
