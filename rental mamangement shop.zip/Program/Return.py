import datetime
import random
import Display  # Make sure Display module is available
import Rent 

# Get the current date and time
dateAndTime = datetime.datetime.now()
presentDateAndTime = dateAndTime.strftime("%m/%d/%Y")

# Function for capturing return details from the user
def forreturning():
    global RName, rentedDate, returnDate
    isrReturn = True
    print("\n********++++++++++ Enter some details of Yourself to generate receipt +++++++**********\n")
    while isrReturn:
        RName = input("\n\t======+++++*******Enter Your name (without any Space)*********++++++++=======\n>>> ").strip()
        if RName == "":
            print("\n!!!!!!! Please, Enter Your name. (Without Space)!!!!!!\n")
        elif RName.isalpha():
            returnNo = random.randint(1, 500)
            rentedDate = input("Enter the day you rented for (format: dd/mm/yyyy): ")
            returnDate = input("Enter the day taken to return (format: dd/mm/yyyy): ")
            with open(RName + "_Return_Receipt.txt", "w") as customFile:
                # Write header information to the receipt file
                customFile.write("""
<=============================*********** ____Happy  Shop___***************====================================>
<~~~~~~~~~~~~~~~~~~~~~~~~~~~~~***********__Return Receipt__ **************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~>""")
                customFile.write(f"Return No: {returnNo}\t\t\t\t\t\t\t\t\t Date: {presentDateAndTime}\n")
                customFile.write(f"\t\t\t\t\t\t\t Customer  Name: {RName}\n")
                customFile.write(f"\t\t\t\t\t\t\tRented Date: {rentedDate}\n")
                customFile.write(f"\t\t\t\t\t\t\tReturn Date: {returnDate}\n")

                customFile.write("\t________________________________________________________________________________________\n\t")
                customFile.write("{:<18} {:<15} {:<15} {:<15} {:<15}{:}".format("Index", "Equipment", "Brand", "Price", "Quantity", "Total"))
                customFile.write("\n\t========================================================================================\n\t")

                break
        else:
            print("\n!!!!!!!!!! Please, Provide proper  customer  name. (Alphabet letters) !!!!!!!!!!!\n")
    
    isrReturn = True
    return isrReturn

# Calculate days difference between rented and return dates
def calculate_days_difference(rentedDate, returnDate):
    days_difference = returnDate - rentedDate
    return days_difference.days

# Function for capturing return details and calculating charges
def returnDetails(isInit):
    try:
        nev = Display.dictionaryEquipments()
        Display.displayequipment()

        total_amount = 0
        late_charge = 0  # Initialize late charge to 0
        while isInit:
            print("\n\t----- Select Equipment  Index of the product you want to return. ----\n")
            product_index = int(input(">>>>>>>>>>>>>> "))
            if product_index in nev.keys():
                product_name = nev[product_index]["name"]
                product_brand = nev[product_index]["brand"]
                product_price = nev[product_index]["price"]
                while True:
                    try:
                        print("\n\t--------- Enter the equipment  of products that you're returning. -------\n")
                        quantity = int(input(">>>>>>>>>>>>>> "))
                        if quantity < 0:
                            print("Please enter a positive integer for the quantity.")
                        elif quantity <= nev[product_index]["quantity"]:
                            price = int(product_price.replace("$", ""))
                            total_amount += price * quantity

                            nev[product_index]["quantity"] += quantity
                            with open(f"{RName}_Return_Receipt.txt", "a+") as sFile:
                                # Write returned product details to the receipt file
                                sFile.write("{:<11} {:<18} {:<15} {:<15} {:<15}{:}".format(product_index, product_name, product_brand, product_price, quantity, price * quantity))
                                sFile.write("\n\t")
                            break
                        else:
                            print("Insufficient quantity of products to return.")
                    except ValueError:
                        print("Please enter a valid integer for the quantity.")
                while True:
                    try:
                        print("\n\tWould you like to return any other products? (yes / no)?\n")
                        choice = input(">>>>>>>>>>>>>> ")
                        if choice.lower() == "no":
                            isInit = False
                            Rent.Equipment(nev)

                            break
                        elif choice.lower() == "yes":
                            break
                        else:
                            print("Please choose 'yes' or 'no'.")
                    except:
                        print("Please choose 'yes' or 'no'.")
            else:
                print("\nProduct Index not found. Please select a valid product Index.")

        print("\n\n<< Successfully returned. >>")
        
        rented_date = datetime.datetime.strptime(rentedDate, "%d/%m/%Y")
        return_date = datetime.datetime.strptime(returnDate, "%d/%m/%Y")
        days_difference = calculate_days_difference(rented_date, return_date)
        # Calculate late charge if returned late by more than 5 days
        if days_difference > 5:
            late_charge = max(days_difference - 5, 0) * 2
        
        total_amount += late_charge

        return total_amount, late_charge

    except Exception as e:
        print(f"Error occurred: {e}")
        return 0, 0

# Function for generating return receipt
def generate_receipt(total_amount, late_charge, RName):
    grand = total_amount + late_charge

    with open(f"{RName}_Return_Receipt.txt", "a+") as customFile:
        # Write total and charges information to the receipt file
        customFile.write(
            """\n\t________________________________________________________________________________________\n""")
        customFile.write("                                Total Amount: $" + str(total_amount) + "\n")
        customFile.write("                                Late Return Charge: $" + str(late_charge) + "\n")
        customFile.write("                              Grand Total with Charges: $" + str(grand))
        customFile.write(
            """\n\t+========================================================================================+\n""")
        customFile.write(
            """+========================================Thanks For returning!========================================+""")

    print(f"""
            !#######################!
            !                       !
            ! Returned Successfully !
            !                       !
            !#######################!
            
            Total Amount: ${total_amount}
            Late Return Charge: ${late_charge}
            Grand Total with Charges: ${grand}
            """)

if __name__ == "__main__":
    isrReturn = forreturning()
    total_amount, late_charge = returnDetails(isrReturn)
    if total_amount > 0:
        generate_receipt(total_amount, late_charge, RName)