# Function to create a dictionary of equipment from data file
def dictionaryEquipments():
    stockItem = {}  # Create an empty dictionary to store equipment data
    try:
        with open("data.txt", "r", encoding="utf-8") as storeRoom:  # Open the data file with specified encoding
            for line in storeRoom:
                data = line.strip().replace("\xa0", " ").split(", ")  # Split the line into data elements
                if len(data) >= 4:  # Check if data contains at least 4 elements
                    index = len(stockItem) + 1  # Calculate index for the equipment
                    price = float(data[2].replace("$", "").replace(",", ""))  # Extract and format the price
                    quantity = int(data[3])  # Extract the quantity
                    total = price * quantity  # Calculate the total value
                    # Store the equipment details in the dictionary
                    stockItem[index] = {
                        "name": data[0],
                        "brand": data[1],
                        "price": data[2],
                        "quantity": quantity,
                        "total": total
                    }
                else:
                    print("Invalid data format:", data)  # Print a message for invalid data
    except FileNotFoundError:
        print("File 'data.txt' not found.")  # Handle file not found error
    except Exception as e:
        print("Error reading data:", e)  # Handle other exceptions
    return stockItem  # Return the dictionary of equipment

# Function to display available equipment
def displayequipment():
    stockItem = dictionaryEquipments()  # Get the equipment dictionary
    print("\n#==================================== Available Stocks of  Equipment ===================================#")
    print("\n=====================================================================================================")
    # Print the header with formatting
    print("\033[31m{:<8} {:<20} {:<15} {:<10} {:<15} {:<15}\033[0m".format("index", "Equipment", "Brand", "Price", "Quantity", "Total"))
    print("=====================================================================================================\n")
    # Iterate through the equipment dictionary and print details with formatting
    for index, data in stockItem.items():
        print("\033[31m{:<8} {:<20} {:<15} {:<10} {:<15} {:<15}\033[0m".format(
            index, data['name'], data['brand'], data['price'], data['quantity'], data['total']))
    print("\n#===================================================================================================#")

# Main code execution
if __name__ == "__main__":
    displayequipment()  # Call the function to display equipment
