# importing some modules
import datetime
from email.errors import InvalidDateDefect
import random
import Display
date = datetime.datetime.now()
currentDate = date.strftime("%m/%d/%Y")
# For Updating Dictionary after  Rent and  Return 
def Equipment(Equipments):
    print(Equipments)
    with open("data.txt", "w") as f:
        for index, details in Equipments.items():
            if details['quantity'] > 0:
                f.write(
                    f"{details['name']}, {details['brand']}, {details['price']}, {details['quantity']}\n")

# Taking some data from Customer and Creating Receipt
def userName():
    global userName
    global isMade
    isMade = True
    print("\n!----------------- Enter Some Details of Customer to generate Receipt -----------------!\n")
    while (isMade):
        # Asking Customer Name
        userName = (input("Enter Customer Name(Without Space) : ")).strip()
        # checking customer name is empty or not
        if userName == " ":
            print("\n!!!!!!!!!! Please, Input Customer Name  Without Space !!!!!!!!!\n")
            isMade = True
        # checking input value is alphabetical name or not
        elif userName.isalpha():
            rentNo = random.randint(1, 500)
            rentDate = input("Enter Rent Date (MM/DD/YYYY): ")
            while not InvalidDateDefect(rentDate):
                print("\n!!!!!!!!!! Please, Enter a valid date in MM/DD/YYYY format !!!!!!!!!\n")
                rentDate = input("Enter Rent Date (MM/DD/YYYY): ")

            with open(userName+"_Rent_Receipt.txt", "w") as customerFile:
                # creating a new text file for Customer Receipt and writing on it
                customerFile.write("""
+==============**************************** Happy  Shop ****************===============================+
    +******************====================  Rent Receipt =====================*******************************+

        """)
                customerFile.write(
                    f"Rent No: {rentNo}\t\t\t\t\t\t\t\t\t Date: {rentDate}\n")
                customerFile.write(
                    f"\t\t\t\t\t\t\tCustomer Name: {userName}\n\n")
                customerFile.write(
                    "\t________________________________________________________________________________________\n\t")
                customerFile.write("{:<18} {:<15} {:<15} {:<15}{:}".format("Name of equipment",
                                                                           "Brand", "Price", "Quantity", "Total"))
                customerFile.write(
                    "\n\t========================================================================================\n\t")
                break
        else:
            print(
                "\n____________/// Please, Input Proper String Name Without Space///___________ \n")
            isMade = True
    return isMade

# Asking Data from Customer to know which equipment  they want to buy

def rentequipment(isMade):
    inventory = Display.dictionaryEquipments()
    Display.displayequipment()
    print("\n")
    global grandTotal
    grandTotal = 0
    global bought
    bought = False  
    while isMade:
        # Asking User To input index number to buy that equipment
        try:
            print(
                "\n\t ////////Choose a index number of equipment from Above listed equipment To Rent////////\n")
            index = int(input(">>>>>>>>>>>>>> "))
            if index in inventory.keys():
                loopRent = True
                while loopRent:
                    try:
                        # Asking User To input Quantity of that selected equipment
                        quantity = int(
                            input("\n\t------------***Enter quantity of  equipment to rent***----------\n\n "))
                        if quantity <= 0:
                            loopRent = True
                            print(
                                "\n *******Please input positive value in quantity********")
                        elif inventory[index]["quantity"] >= quantity:
                            loopRent = False
                            bought = True
                            # changing dollar sign in price to emptystring
                            price = int(
                                inventory[index]['price'].replace("$", ""))
                            price1 = price * quantity
                            grandTotal = grandTotal + price1
                            with open(f"{userName}_Rent_Receipt.txt", "a+") as customer:
                                customer.write("{:<18} {:<15} {:<15} {:<15}{:}".format(inventory[index]['name'],
                                               inventory[index]['brand'], inventory[index]['price'], quantity, price1))
                                customer.write("\n\t")
                            inventory[index]["quantity"] -= quantity
                        else:
                            print(
                                "\n!!!!!!!! Insufficient quantity of equipment !!!!!!!\n")
                            loopRent = True
                    except:
                        print(
                            "\n!!!!!!! Please, Input Integer Number in Quantity !!!!!!!!\n")
                        loopRent = True
            else:
                print(
                    "\n!!!@@@@@@@@@!!! index number Not Found / See equipment index Carefully !!!@@@@@@@@@@!!!!\n")
                isMade = True
        except:
            print("\n*************!!!!!!! Please, Input Proper index Integer Number !!!!!!!!*************\n")
            isMade = True
        while bought:
            print("\n\t**********---- Do you Want to Buy More ( y- yes/ n - No)?----**********\n")
            buyMore = input(">>>>>>>>>>>>>> ")
            if buyMore.lower() == "y":
                isMade = True
                loopRent = True
                bought = False
            elif buyMore.lower() == "n":
                isMade = False
                bought = False
                Equipment(inventory)
            else:
                print("\n!!!!!!! Please, Choose ('y' or 'n') !!!!!!!!!\n")

def AllTotal():
    totalPrice = grandTotal
    print("""
                         |**************************************************|
                         |***  Do you want to  Rent physically or Online?***|
                         |*** -------------------------------------------***|
                         |***              1 for: Physical               ***|
                         |***              2 for: Online                 ***|
                         |**************************************************|""")
    while True:
        try:
            ship = int(input(">> "))
            if ship == 2:
                # Adding Shipping Charge
                total_Ship_Price = totalPrice + 500
                with open(f"{userName}_Rent_Receipt.txt", "a+") as customer:
                    customer.write(
                        """\n\t________________________________________________________________________________________\n""")
                    customer.write(
                        "                                                           Total Price: $"+str(totalPrice)+"\n")
                    customer.write(
                        "                                                           Shipping Charge: $500\n")
                    customer.write(
                        "                                                           Total with Shipping charge: $"+str(total_Ship_Price))
                    customer.write(
                        """\n\t+========================================================================================+\n""")
                    customer.write(
                        """+========================================Thanks For  Choosing us ========================================+""")
                print("""
                        !___________________________!
                        !                           !
                        !     Rented Successfully   !
                        !                           !
                        !___________________________!""")
                return
            elif ship == 1:
                with open(f"{userName}_rent_Receipt.txt", "a+") as customer:
                    customer.write(
                        """\n\t________________________________________________________________________________________\n""")
                    customer.write(
                        "                                                             Total Price: $"+str(totalPrice)+"\n")
                    customer.write(
                        """\t+===========================================================================================+\n""")
                    customer.write(
                        """+========================================Thanks For  Renting ========================================+""")

                print("""
                        ! ----------------------!
                        !                       !
                        !  Rented  Successfully !
                        !                       !
                        ! ----------------------!""")
                return
            else:
                print("\n\t---------- Please, Choose a Given Option 1 or 2 ----------\n")
        except:
            print("\n!!!!!!!! Please, Enter Valid Option of Integer !!!!!!!!!!\n")
        totalPrice = 0
